namespace Mena.Apis.CustomerPortal
{
    using Microsoft.AspNetCore.Hosting;
    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.Hosting;

    public class Program
    {
        public static void Main(string[] args)
        {
            CreateHostBuilder(args).Build().Run();
        }

        public static IHostBuilder CreateHostBuilder(string[] args) => //IWebHost
             Host.CreateDefaultBuilder(args)
             .ConfigureWebHostDefaults((webBuilder) => {
                 webBuilder.ConfigureAppConfiguration((hostingContext, config) =>
                 {
                     config.AddXmlFile("appsettings.xml", optional: false, reloadOnChange: true);
                 })
                 .UseStartup<Startup>()
                 .ConfigureKestrel((context, options) =>
                 {
                     var Url = context.Configuration["HttpWebHostUrl"];
                     Url = string.IsNullOrEmpty(Url) ? "http://0.0.0.0:7000" : Url;
                     context.Configuration[WebHostDefaults.ServerUrlsKey] = Url;
                 });
             });
    }
}
