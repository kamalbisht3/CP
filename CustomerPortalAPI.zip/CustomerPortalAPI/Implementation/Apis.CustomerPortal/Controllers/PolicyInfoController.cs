﻿namespace Apis.CustomerPortal.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using Mena.Apis.CustomerPortal.Contracts.Request.Policy;
    using Mena.Apis.CustomerPortal.Contracts.Response.Policy;
    using Mena.Apis.CustomerPortal.DataAccess.Repositories.Contracts;
    using Mena.Components.Core.Extensions;
    using Mena.Components.Core.Instrumentation.Contracts;
    using Mena.Components.Web.Core.Mvc;
    using Microsoft.AspNetCore.Mvc;

    [Route("api/customer/[controller]")]
    public class PolicyInfoController : ApiBaseController   
    {
        private IPolicyInfoRepository _identityRepository;
        public PolicyInfoController(IPolicyInfoRepository identityRepository, ILogger logger) : base(logger)
        {
            _identityRepository = identityRepository;
        }

        [HttpPost("details")]
        public async Task<IActionResult> GetVehicleInfo([FromBody]PolicyInfoRequest userEmail)
        {
            var result = await _identityRepository.GetPolicyInfo(userEmail.Email);
            if (!result.IsNullOrEmpty())
            {
                return Ok<List<PolicyInformation>>(result);
            }
            return NotFoundResponse();
        }
    }
}