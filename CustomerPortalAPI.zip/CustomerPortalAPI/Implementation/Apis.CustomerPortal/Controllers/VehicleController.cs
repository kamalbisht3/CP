﻿namespace Mena.Apis.CustomerPortal.Controllers
{
    using Mena.Apis.CustomerPortal.Contracts.Request.Vehicle;
    using Mena.Apis.CustomerPortal.Contracts.Response.Vehicle;
    using Mena.Apis.CustomerPortal.DataAccess.Repositories.Contracts;
    using Mena.Components.Core.Extensions;
    using Mena.Components.Core.Instrumentation.Contracts;
    using Mena.Components.Web.Core.Mvc;
    using Microsoft.AspNetCore.Mvc;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;

    [Route("api/customer/[controller]")]
    public class VehicleController : ApiBaseController
    {
        private IVehicleRepository _identityRepository;
        public VehicleController(IVehicleRepository identityRepository, ILogger logger) : base(logger)
        {
            _identityRepository = identityRepository;
        }

        [HttpPost("info")]
        public async Task<IActionResult> GetVehicleInfo([FromBody]VehicleRequest userEmail)
        {
            var result = await _identityRepository.GetVehicleInfo(userEmail.Email);
            if (!result.IsNullOrEmpty())
            {
                return Ok<List<VehicleInfo>>(result);
            }
            return NotFoundResponse();
        }
    }
}
