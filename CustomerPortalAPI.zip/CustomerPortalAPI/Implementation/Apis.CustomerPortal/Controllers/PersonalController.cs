﻿namespace Mena.Apis.CustomerPortal.Controllers
{
    using System.Linq;
    using System.Threading.Tasks;
    using Mena.Api.Identity.DataAccess.Repositories.Contracts;
    using Mena.Apis.CustomerPortal.Contracts.Request.Auth;
    using Mena.Apis.CustomerPortal.Contracts.Request.Personal;
    using Mena.Apis.CustomerPortal.Contracts.Response.Auth;
    using Mena.Apis.CustomerPortal.Contracts.Response.Personal;
    using Mena.Components.Core.Extensions;
    using Mena.Components.Core.Instrumentation.Contracts;
    using Mena.Components.Web.Core.Mvc;
    using Microsoft.AspNetCore.Mvc;

    [Route("api/customer/[controller]")]
    public class PersonalController : ApiBaseController
    {
        /// <summary>
        /// The identity repository
        /// </summary>
        private IPersonalRepository _personalRepository;
        /// <summary>
        /// Initializes a new instance of the <see cref="CustomerController"/> class.
        /// </summary>
        /// <param name="identityRepository">The identity repository.</param>
        /// <param name="logger">The logger.</param>
        public PersonalController(IPersonalRepository personalRepository, ILogger logger) : base(logger)
        {
            _personalRepository = personalRepository;
        }

        /// <summary>
        /// Creates the user.
        /// </summary>
        /// <param name="userCreateRequest">The user create request.</param>
        /// <returns></returns>
        [HttpPost("personalinfo")]
        public async Task<IActionResult> PersonalDetail([FromBody]PersonalDetailRequest personaldetail)
        {
            if (personaldetail == null)
            {
                return BadRequestResponse();
            }
            var result = await _personalRepository.GetPersonalDetail(personaldetail);
            if (!result.IsNullOrEmpty())
            {
                var data = Ok<PersonalDetailResult>(result.First());
                return data;
            }
            return NotFoundResponse();
        }

    }
}