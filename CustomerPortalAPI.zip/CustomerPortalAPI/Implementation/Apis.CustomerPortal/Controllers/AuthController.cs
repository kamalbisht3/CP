﻿namespace Mena.Apis.CustomerPortal.Controllers
{
    using System.Linq;
    using System.Threading.Tasks;
    using Mena.Api.Identity.DataAccess.Repositories.Contracts;
    using Mena.Apis.CustomerPortal.Contracts.Request.Auth;
    using Mena.Apis.CustomerPortal.Contracts.Response.Auth;
    using Mena.Components.Core.Extensions;
    using Mena.Components.Core.Instrumentation.Contracts;
    using Mena.Components.Web.Core.Mvc;
    using Microsoft.AspNetCore.Mvc;

    [Route("api/customer/[controller]")]
    public class AuthController : ApiBaseController
    {
        /// <summary>
        /// The identity repository
        /// </summary>
        private IAuthRepository _identityRepository;
        /// <summary>
        /// Initializes a new instance of the <see cref="CustomerController"/> class.
        /// </summary>
        /// <param name="identityRepository">The identity repository.</param>
        /// <param name="logger">The logger.</param>
        public AuthController(IAuthRepository identityRepository, ILogger logger) : base(logger)
        {
            _identityRepository = identityRepository;
        }

        /// <summary>
        /// Creates the user.
        /// </summary>
        /// <param name="userCreateRequest">The user create request.</param>
        /// <returns></returns>
        [HttpPost("createuser")]
        public async Task<IActionResult> CreateUser([FromBody]UserCreateRequest userCreateRequest)
        {
            if (userCreateRequest == null)
            {
                return BadRequestResponse();
            }
            var result = await _identityRepository.CreateUser(userCreateRequest);
            if (!result.IsNullOrEmpty())
            {
                var data = Ok<UserCreateResult>(result.First());
                return data;
            }
            return NotFoundResponse();
        }

        /// <summary>
        /// Creates the forgot link.
        /// </summary>
        /// <param name="forgotLinkRequest">The forgot link request.</param>
        /// <returns></returns>
        [HttpPost("createforgotlink")]
        public async Task<IActionResult> CreateForgotLink([FromBody]ForgotLinkRequest forgotLinkRequest)
        {
            if (forgotLinkRequest == null)
            {
                return BadRequestResponse();
            }
            var result = await _identityRepository.CreateForgotLink(forgotLinkRequest);
            if (!result.IsNullOrEmpty())
            {
                var data = Ok<ForgotLinkResult>(result.First());
                return data;
            }
            return NotFoundResponse();
        }

        /// <summary>
        /// Logins the validate.
        /// </summary>
        /// <param name="loginValidateRequest">The login validate request.</param>
        /// <returns></returns>
        [HttpPost("loginvalidate")]
        public async Task<IActionResult> LoginValidate([FromBody]LoginValidateRequest loginValidateRequest)
        {
            if (loginValidateRequest == null)
            {
                return BadRequestResponse();
            }
            var result = await _identityRepository.LoginValidate(loginValidateRequest);
            if (!result.IsNullOrEmpty())
            {
                var data = Ok<LoginValidateResult>(result.First());
                return data;
            }
            return NotFoundResponse();
        }

        /// <summary>
        /// Resets the password.
        /// </summary>
        /// <param name="passwordResetRequest">The password reset request.</param>
        /// <returns></returns>
        [HttpPost("resetpassword")]
        public async Task<IActionResult> ResetPassword([FromBody]PasswordResetRequest passwordResetRequest)
        {
            if (passwordResetRequest == null)
            {
                return BadRequestResponse();
            }
            var result = await _identityRepository.ResetPassword(passwordResetRequest);
            if (!result.IsNullOrEmpty())
            {
                var data = Ok<PasswordResetResult>(result.First());
                return data;
            }
            return NotFoundResponse();
        }

        /// <summary>
        /// Validates the forgot link.
        /// </summary>
        /// <param name="forgotLinkValidRequest">The forgot link valid request.</param>
        /// <returns></returns>
        [HttpPost("validateforgotlink")]
        public async Task<IActionResult> ValidateForgotLink([FromBody]ForgotLinkValidRequest forgotLinkValidRequest)
        {
            if (forgotLinkValidRequest == null)
            {
                return BadRequestResponse();
            }
            var result = await _identityRepository.ValidateForgotLink(forgotLinkValidRequest);
            if (!result.IsNullOrEmpty())
            {
                var data = Ok<ForgotLinkValidResult>(result.First());
                return data;
            }
            return NotFoundResponse();
        }
    }
}