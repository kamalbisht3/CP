﻿namespace Mena.Apis.CustomerPortal.Controllers
{
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using Mena.Apis.CustomerPortal.Contracts.Enums;
    using Mena.Apis.CustomerPortal.Contracts.Request.File;
    using Mena.Apis.CustomerPortal.Contracts.Response.File;
    using Mena.Apis.CustomerPortal.DataAccess.Repositories.Contracts;
    using Mena.Components.Core.Extensions;
    using Mena.Components.Core.Instrumentation.Contracts;
    using Mena.Components.Web.Core.Mvc;
    using Microsoft.AspNetCore.Mvc;
    [Route("api/customer/[controller]")]
    public class FileController : ApiBaseController
    {
        /// <summary>
        /// The identity repository
        /// </summary>
        private IFileRepository _fileRepository;
        /// <summary>
        /// FileController
        /// </summary>
        /// <param name="fileRepository"></param>
        /// <param name="logger"></param>
        public FileController(IFileRepository fileRepository, ILogger logger) : base(logger)
        {
            _fileRepository = fileRepository;
        }
        /// <summary>
        /// Creates the user.
        /// </summary>
        /// <param name="userCreateRequest">The user create request.</param>
        /// <returns></returns>
        [HttpPost("UploadFile")]
        public async Task<IActionResult> UploadFile([FromBody] List<FileInsertRequest> fileInsertRequestList)
        {
            var result = 0;
            foreach(var fileInsertRequest in fileInsertRequestList)
            {
                if (fileInsertRequest == null)
                {
                    return BadRequestResponse();
                }
                 result = await _fileRepository.FileInsert(fileInsertRequest);
            }
            if (result != 0)
            {
                return Ok(result);
            }
            return NotFoundResponse();
        }

        [HttpPost("GetUploadedFile")]
        public async Task<IActionResult> GetUploadedFile([FromBody] FileGetRequest fileGetRequest)
        {
            if (fileGetRequest == null)
                {
                    return BadRequestResponse();
                }
                var result = await _fileRepository.FileGet(fileGetRequest);
            
                var data = Ok(result);
                return data;            
        }

        [HttpPost("deletefile")]
        public async Task<IActionResult> DeleteFile([FromBody] FileDeleteRequest fileDeleteRequest)
        {
            if (fileDeleteRequest == null)
            {
                return BadRequestResponse();
            }

            var result = await _fileRepository.DeleteFile(fileDeleteRequest);
            if (result != 0)
            {
                var data = Ok(result);
                return data;
            }
            return NotFoundResponse();
        }
    }
}