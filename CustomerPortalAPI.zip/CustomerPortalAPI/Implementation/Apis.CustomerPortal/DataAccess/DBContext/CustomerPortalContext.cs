﻿namespace Mena.Api.Identity.DataAccess.DBContext
{
    using Mena.Apis.CustomerPortal.Contracts.Response.Auth;
    using Mena.Apis.CustomerPortal.Contracts.Response.File;
    using Mena.Apis.CustomerPortal.Contracts.Response.Personal;
    using Mena.Apis.CustomerPortal.Contracts.Response.Policy;
    using Mena.Apis.CustomerPortal.Contracts.Response.QuoteHistory;
    using Mena.Apis.CustomerPortal.Contracts.Response.Vehicle;
    using Mena.Components.Core.Extensions.EntityFrameworkCore;
    using Microsoft.EntityFrameworkCore;
    using System.Reflection;



    /// <summary>
    /// IdentityContext
    /// </summary>
    /// <seealso cref="DbContext" />
    public partial class CustomerPortalContext : DbContext
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CustomerPortalContext"/> class.
        /// </summary>
        /// <param name="options">The options.</param>
        public CustomerPortalContext(DbContextOptions<CustomerPortalContext> options) : base(options)
        {
        }


        /// <summary>
        /// Called when [model creating].
        /// </summary>
        /// <param name="builder">The builder.</param>
        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);
            builder.AddQueryModels(GetAssemblies(), typeof(IQueryAuthModel));
            builder.AddQueryModels(GetAssemblies(), typeof(IQueryUserDetailModel));
            builder.AddQueryModels(GetAssemblies(), typeof(IQueryVehicleDetailModel));
            builder.AddQueryModels(GetAssemblies(), typeof(IQueryPolicyInfoModel));
            builder.AddQueryModels(GetAssemblies(), typeof(IQueryQuoteHistoryModel));
            builder.AddQueryModels(GetAssemblies(), typeof(IQueryFileModel));
        }


        /// <summary>
        /// Gets the assemblies.
        /// </summary>
        public Assembly[] GetAssemblies()
        {
            return new Assembly[] { typeof(UserCreateResult).Assembly, typeof(PersonalDetailResult).Assembly, typeof(VehicleInfo).Assembly, typeof(PolicyInformation).Assembly, typeof(QuoteHistory).Assembly, typeof(FileInsertResult).Assembly, typeof(FileGetResult).Assembly };
        }


        /// <summary>
        /// Gets or sets the customer.
        /// </summary>
        /// <value>
        /// The customer.
        /// </value>
       // public virtual DbSet<Customer> Customer { get; set; }
    }
}
