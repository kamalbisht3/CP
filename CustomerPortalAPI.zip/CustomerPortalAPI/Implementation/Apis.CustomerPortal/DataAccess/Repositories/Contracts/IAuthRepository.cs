﻿namespace Mena.Api.Identity.DataAccess.Repositories.Contracts
{
    using Mena.Apis.CustomerPortal.Contracts.Request.Auth;
    using Mena.Apis.CustomerPortal.Contracts.Response.Auth;
    using System.Collections.Generic;
    using System.Threading.Tasks;

    /// <summary>
    /// IIdentityRepository
    /// </summary>
    public interface IAuthRepository
    {
        /// <summary>
        /// Creates the forgot link.
        /// </summary>
        /// <param name="forgotLinkRequest">The forgot link request.</param>
        /// <returns></returns>
        Task<List<ForgotLinkResult>> CreateForgotLink(ForgotLinkRequest forgotLinkRequest);
        /// <summary>
        /// Creates the user.
        /// </summary>
        /// <param name="userCreateRequest">The user create request.</param>
        /// <returns></returns>
        Task<List<UserCreateResult>> CreateUser(UserCreateRequest userCreateRequest);
        /// <summary>
        /// Logins the validate.
        /// </summary>
        /// <param name="loginValidateRequest">The login validate request.</param>
        /// <returns></returns>
        Task<List<LoginValidateResult>> LoginValidate(LoginValidateRequest loginValidateRequest);
        /// <summary>
        /// Resets the password.
        /// </summary>
        /// <param name="passwordResetRequest">The password reset request.</param>
        /// <returns></returns>
        Task<List<PasswordResetResult>> ResetPassword(PasswordResetRequest passwordResetRequest);
        /// <summary>
        /// Validates the forgot link.
        /// </summary>
        /// <param name="forgotLinkValidRequest">The forgot link valid request.</param>
        /// <returns></returns>
        Task<List<ForgotLinkValidResult>> ValidateForgotLink(ForgotLinkValidRequest forgotLinkValidRequest);
    }
}
