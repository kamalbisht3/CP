﻿namespace Mena.Apis.CustomerPortal.DataAccess.Repositories.Contracts
{
    using Mena.Apis.CustomerPortal.Contracts.Response.QuoteHistory;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;

    public interface IQuoteHistoryRepository
    {
        Task<List<QuoteHistory>> GetQuoteHistory(string email);
    }
}
