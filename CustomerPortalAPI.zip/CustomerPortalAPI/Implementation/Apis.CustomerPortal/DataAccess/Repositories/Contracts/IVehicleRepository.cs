﻿namespace Mena.Apis.CustomerPortal.DataAccess.Repositories.Contracts
{
    using Mena.Apis.CustomerPortal.Contracts.Response.Vehicle;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;

    public interface IVehicleRepository
    {
        Task<List<VehicleInfo>> GetVehicleInfo(string email);
    }
}
