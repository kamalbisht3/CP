﻿namespace Mena.Apis.CustomerPortal.DataAccess.Repositories.Implementations
{
    using Mena.Api.Identity.DataAccess.DBContext;
    using Mena.Apis.CustomerPortal.Constants;
    using Mena.Apis.CustomerPortal.Contracts.Response.Policy;
    using Mena.Apis.CustomerPortal.DataAccess.Repositories.Contracts;
    using Mena.Components.Core.Extensions.EntityFrameworkCore;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;

    public class PolicyInfoRepository : IPolicyInfoRepository
    {
        private CustomerPortalContext _identityContext;

        public PolicyInfoRepository(CustomerPortalContext identityContext)
        {
            _identityContext = identityContext;
        }

        public Task<List<PolicyInformation>> GetPolicyInfo(string EmailAddress)
        {
            var sqlData = new Dictionary<string, object>
                {
                    {"EmailAddress",EmailAddress}
                }.ToSql(SpConstant.PolicyInfo);
            return _identityContext.FromSqlAsync<PolicyInformation>(sqlData.sqlString, sqlData.sqlParameters);
        }
    }
}
