﻿
namespace Mena.Apis.CustomerPortal.Contracts.Enums
{
    public enum InsertFileStatus
    {
      Success=-1,
      Failed=0
    }
}
