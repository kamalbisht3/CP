﻿namespace Mena.Apis.CustomerPortal.Contracts.Enums
{
    public enum ForgotLinkCreateStaus
    {
        NoAccount,
        Value
    }
}
