﻿namespace Mena.Apis.CustomerPortal.Contracts.Enums
{
    public enum ForgotLinkValidateStatus
    {
        NoMatch,
        Valid,
        Used,
        Expired
    }
}
