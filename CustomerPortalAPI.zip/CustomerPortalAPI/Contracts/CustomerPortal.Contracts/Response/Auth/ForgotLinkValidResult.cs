﻿namespace Mena.Apis.CustomerPortal.Contracts.Response.Auth
{
    public class ForgotLinkValidResult : IQueryAuthModel
    {
        public Enums.ForgotLinkValidateStatus Status { get; set; }
        public string ResultSet { get; set; }
    }
}
