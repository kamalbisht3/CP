﻿namespace Mena.Apis.CustomerPortal.Contracts.Response.Auth
{
    public interface IQueryAuthModel
    {
    }
}