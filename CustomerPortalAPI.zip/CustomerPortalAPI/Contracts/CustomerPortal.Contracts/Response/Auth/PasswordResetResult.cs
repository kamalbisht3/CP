﻿namespace Mena.Apis.CustomerPortal.Contracts.Response.Auth
{
    public class PasswordResetResult : IQueryAuthModel
    {
        public Enums.PasswordResetStatus Status { get; set; }
        public string ResultSet { get; set; }
    }
}
