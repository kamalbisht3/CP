﻿namespace Mena.Apis.CustomerPortal.Contracts.Response.Personal
{
    public interface IQueryUserDetailModel
    {
    }
}