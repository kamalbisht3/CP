﻿namespace Mena.Apis.CustomerPortal.Contracts.Response.Personal
{
    using System;

    public class PersonalDetailResult : IQueryUserDetailModel
    {
        //public Enums.UserCreateStaus Status { get; set; }
        public Guid CustomerActivityID { get; set; }
        public string Risk { get; set; }
    }
}
