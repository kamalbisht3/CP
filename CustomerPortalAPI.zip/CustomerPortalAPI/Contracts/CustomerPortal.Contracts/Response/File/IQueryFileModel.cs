﻿namespace Mena.Apis.CustomerPortal.Contracts.Response.File
{
    public interface IQueryFileModel
    {
    }
}
