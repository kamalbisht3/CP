﻿using Mena.Apis.CustomerPortal.Contracts.Enums;

namespace Mena.Apis.CustomerPortal.Contracts.Response.File
{
   public class FileInsertResult: IQueryFileModel
    {
      public InsertFileStatus Status { get; set; }
    }
}
