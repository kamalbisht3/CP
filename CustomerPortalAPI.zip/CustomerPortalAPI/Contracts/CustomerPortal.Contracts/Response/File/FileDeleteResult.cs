﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Mena.Apis.CustomerPortal.Contracts.Response.File
{
    public class FileDeleteResult : IQueryFileModel
    {
        public int result { get; set; }
    }
}
