﻿namespace Mena.Apis.CustomerPortal.Contracts.Response.Policy
{
    using System;

    public class PolicyInformation: IQueryPolicyInfoModel
    {
        public string Risk { get; set; }
        public long PolicyInfoID { get; set; }
        public Guid CustomerActivity_ID { get; set; }
        public short Brand_ID { get; set; }
        public string ProposalNumber { get; set; }
        public string PolicyNumber { get; set; }
        public string PolicyInfo { get; set; }
    }
}
