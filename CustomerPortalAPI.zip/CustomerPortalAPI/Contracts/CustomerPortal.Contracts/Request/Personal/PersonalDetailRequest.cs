﻿namespace Mena.Apis.CustomerPortal.Contracts.Request.Personal
{
    public class PersonalDetailRequest
    {
        public string EmailAddress { get; set; }
    }
}
