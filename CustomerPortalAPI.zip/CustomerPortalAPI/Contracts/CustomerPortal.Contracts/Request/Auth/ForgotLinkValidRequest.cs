﻿namespace Mena.Apis.CustomerPortal.Contracts.Request.Auth
{
    public class ForgotLinkValidRequest     {
        public string Identifier { get; set; }
    }
}
