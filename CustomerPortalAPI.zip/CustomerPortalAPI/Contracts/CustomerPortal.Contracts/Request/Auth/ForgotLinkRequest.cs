﻿namespace Mena.Apis.CustomerPortal.Contracts.Request.Auth
{
    public class ForgotLinkRequest 
    {
        public string EmailAddress { get; set; }
    }
}
